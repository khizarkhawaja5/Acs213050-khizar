

![image](https://github.com/umarnisar1/CRUD_Operation_With_Avatar_Column_BY_Umar_and_Ali/assets/111348261/2126f712-0d2a-4d97-bc65-275e1640ba76)
![image](https://github.com/umarnisar1/CRUD_Operation_With_Avatar_Column_BY_Umar_and_Ali/assets/111348261/4479b846-c84c-4f98-9855-81f3cbdf093b)
